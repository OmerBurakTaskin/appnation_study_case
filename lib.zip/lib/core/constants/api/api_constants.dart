class ApiConstants {
  static String dogBreedBaseUrl = "https://dog.ceo/api/breed/";
  static String dogBreedsBaseUrl = "https://dog.ceo/api/breeds/";
}
