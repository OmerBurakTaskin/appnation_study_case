enum LoadingStateEnum {
  initial,
  loading,
  done,
  error,
}