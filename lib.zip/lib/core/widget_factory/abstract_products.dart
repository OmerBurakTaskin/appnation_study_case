import 'package:flutter/material.dart';

abstract class NativeLoadingIndicator extends StatelessWidget{
  const NativeLoadingIndicator({super.key});
}